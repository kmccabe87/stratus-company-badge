(() => {
  "use strict";

  const HOST_ID = "svm-stratus-company-badge-host";
  const STORAGE_KEYS = [
    "manualCompany",
    "manualStation",
    "detectedCompany",
    "detectedStation"
  ];
  const COMPANY_LABEL_PATTERN = /^signed\s+into\s*:?\s*$/i;
  const COMPANY_INLINE_PATTERN = /^signed\s+into(?!\s+station\b)\s*:?\s+(.+)$/i;
  const STATION_LABEL_PATTERN = /^signed\s+into\s+station\s*:?\s*$/i;
  const STATION_INLINE_PATTERN = /^signed\s+into\s+station\s*:?\s+(.+)$/i;
  const INVALID_VALUE_PATTERN =
    /^(company|station|signed into|signed into station|account settings|refresh permissions|log out|logout)$/i;

  let shadowRoot = null;
  let companyValueElement = null;
  let stationValueElement = null;
  let mutationTimer = null;
  let lastMenuProbeAt = 0;
  let detectionRunning = false;

  function normalizeText(value) {
    return String(value ?? "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isPlausibleValue(value) {
    const text = normalizeText(value);
    return (
      text.length >= 2 &&
      text.length <= 120 &&
      !INVALID_VALUE_PATTERN.test(text) &&
      !/^signed\s+into\b/i.test(text)
    );
  }

  function ensureBadge() {
    let host = document.getElementById(HOST_ID);

    if (!host) {
      host = document.createElement("div");
      host.id = HOST_ID;
      host.setAttribute("aria-live", "polite");
      host.setAttribute("title", "Current STRATUS company and station");
      document.documentElement.appendChild(host);

      shadowRoot = host.attachShadow({ mode: "open" });

      const style = document.createElement("style");
      style.textContent = `
        :host {
          all: initial;
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 0;
          z-index: 2147483647;
          pointer-events: none;
        }

        .badge {
          position: absolute;
          top: 5px;
          left: 50%;
          transform: translateX(-50%);
          z-index: 2147483647;
          display: inline-flex;
          align-items: center;
          min-height: 26px;
          max-width: min(680px, 58vw);
          padding: 0 11px;
          box-sizing: border-box;
          border: 1px solid rgba(255, 255, 255, 0.22);
          border-radius: 5px;
          background: rgba(25, 25, 25, 0.96);
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.38);
          color: #ffffff;
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
          line-height: 1;
          pointer-events: none;
          user-select: none;
        }

        .field {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          min-width: 0;
        }

        .label {
          flex: none;
          color: #9db4c7;
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .value {
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          font-weight: 600;
        }

        .separator {
          flex: none;
          width: 1px;
          height: 16px;
          margin: 0 11px;
          background: rgba(255, 255, 255, 0.34);
        }

        .badge[data-state="waiting"] .value[data-missing="true"] {
          color: #d8d8d8;
          font-weight: 400;
        }

        @media (max-width: 1050px) {
          .badge {
            left: auto;
            right: 185px;
            transform: none;
            max-width: 54vw;
          }
        }

        @media (max-width: 760px) {
          .badge {
            display: none;
          }
        }
      `;

      const badge = document.createElement("div");
      badge.className = "badge";
      badge.dataset.state = "waiting";

      const companyField = document.createElement("span");
      companyField.className = "field";

      const companyLabel = document.createElement("span");
      companyLabel.className = "label";
      companyLabel.textContent = "COMPANY";

      companyValueElement = document.createElement("span");
      companyValueElement.className = "value";
      companyValueElement.dataset.field = "company";
      companyValueElement.textContent = "Detecting…";
      companyValueElement.dataset.missing = "true";

      companyField.append(companyLabel, companyValueElement);

      const separator = document.createElement("span");
      separator.className = "separator";
      separator.setAttribute("aria-hidden", "true");

      const stationField = document.createElement("span");
      stationField.className = "field";

      const stationLabel = document.createElement("span");
      stationLabel.className = "label";
      stationLabel.textContent = "STATION";

      stationValueElement = document.createElement("span");
      stationValueElement.className = "value";
      stationValueElement.dataset.field = "station";
      stationValueElement.textContent = "Detecting…";
      stationValueElement.dataset.missing = "true";

      stationField.append(stationLabel, stationValueElement);
      badge.append(companyField, separator, stationField);
      shadowRoot.append(style, badge);
    } else if (!shadowRoot) {
      shadowRoot = host.shadowRoot;
      companyValueElement = shadowRoot?.querySelector('[data-field="company"]') ??
        shadowRoot?.querySelector(".field:first-of-type .value") ?? null;
      stationValueElement = shadowRoot?.querySelector('[data-field="station"]') ??
        shadowRoot?.querySelector(".field:last-of-type .value") ?? null;
    }

    return host;
  }

  function renderDetails(company, station, state = "ready", missingText = "Detecting…") {
    ensureBadge();
    const badge = shadowRoot?.querySelector(".badge");
    if (!badge || !companyValueElement || !stationValueElement) return;

    const normalizedCompany = normalizeText(company);
    const normalizedStation = normalizeText(station);

    badge.dataset.state = state;
    companyValueElement.textContent = normalizedCompany || missingText;
    companyValueElement.dataset.missing = String(!normalizedCompany);
    stationValueElement.textContent = normalizedStation || missingText;
    stationValueElement.dataset.missing = String(!normalizedStation);
  }

  function linesFromElement(element) {
    return String(element?.innerText ?? "")
      .split(/\r?\n/)
      .map(normalizeText)
      .filter(Boolean);
  }

  function extractValueFromLabelElement(labelElement, labelPattern, inlinePattern) {
    const directText = normalizeText(labelElement.textContent);
    const inlineMatch = directText.match(inlinePattern);
    if (inlineMatch && isPlausibleValue(inlineMatch[1])) {
      return normalizeText(inlineMatch[1]);
    }

    let current = labelElement;
    for (let level = 0; current && current !== document.body && level < 7; level += 1) {
      const lines = linesFromElement(current);
      const labelIndex = lines.findIndex((line) => labelPattern.test(line));

      if (labelIndex >= 0) {
        for (let i = labelIndex + 1; i < Math.min(lines.length, labelIndex + 4); i += 1) {
          if (isPlausibleValue(lines[i])) return lines[i];
        }
      }

      current = current.parentElement;
    }

    const siblingCandidates = [];
    let sibling = labelElement.nextElementSibling;
    for (let i = 0; sibling && i < 4; i += 1, sibling = sibling.nextElementSibling) {
      siblingCandidates.push(...linesFromElement(sibling));
    }

    return siblingCandidates.find(isPlausibleValue) ?? null;
  }

  function findLabeledValueInDom(labelPattern, inlinePattern) {
    if (!document.body) return null;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const text = normalizeText(node.nodeValue);
          if (labelPattern.test(text) || inlinePattern.test(text)) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
      }
    );

    let node;
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      if (!parent) continue;

      const value = extractValueFromLabelElement(parent, labelPattern, inlinePattern);
      if (value) return value;
    }

    return null;
  }

  function findSignedInDetailsInDom() {
    return {
      company: findLabeledValueInDom(COMPANY_LABEL_PATTERN, COMPANY_INLINE_PATTERN),
      station: findLabeledValueInDom(STATION_LABEL_PATTERN, STATION_INLINE_PATTERN)
    };
  }

  function looksLikeStratusApplication() {
    const text = normalizeText(document.body?.innerText?.slice(0, 12000));
    return /assemblies/i.test(text) && /jobsites/i.test(text);
  }

  function candidateScore(element) {
    const rect = element.getBoundingClientRect();
    if (
      rect.width < 12 ||
      rect.height < 12 ||
      rect.bottom < 0 ||
      rect.top > 85 ||
      rect.right < window.innerWidth * 0.65
    ) {
      return -Infinity;
    }

    const descriptor = normalizeText(
      [
        element.getAttribute("aria-label"),
        element.getAttribute("title"),
        element.id,
        element.className,
        element.parentElement?.className
      ].join(" ")
    ).toLowerCase();

    let score = 0;
    if (/(account|profile|user|avatar|identity)/.test(descriptor)) score += 10;
    if (/(dropdown|menu|toggle)/.test(descriptor)) score += 4;
    if (element.matches('[aria-haspopup="menu"], [aria-haspopup="true"]')) score += 4;
    if (element.matches(".dropdown-toggle, [data-toggle='dropdown'], [data-bs-toggle='dropdown']")) score += 4;
    if (element.querySelector("img, svg")) score += 2;
    if (rect.right > window.innerWidth * 0.9) score += 3;
    score += rect.right / Math.max(window.innerWidth, 1);

    return score;
  }

  function findLikelyAccountToggle() {
    const selectors = [
      '[aria-label*="account" i]',
      '[aria-label*="profile" i]',
      '[aria-label*="user" i]',
      '[title*="account" i]',
      '[title*="profile" i]',
      '[title*="user" i]',
      ".dropdown-toggle",
      "[data-toggle='dropdown']",
      "[data-bs-toggle='dropdown']",
      '[aria-haspopup="menu"]',
      '[aria-haspopup="true"]'
    ];

    const candidates = [...new Set(document.querySelectorAll(selectors.join(",")))]
      .map((element) => ({ element, score: candidateScore(element) }))
      .filter((item) => Number.isFinite(item.score))
      .sort((a, b) => b.score - a.score);

    return candidates[0]?.score >= 5 ? candidates[0].element : null;
  }

  function delay(milliseconds) {
    return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
  }

  function displayedDetails(stored) {
    return {
      company: normalizeText(stored.manualCompany) || normalizeText(stored.detectedCompany),
      station: normalizeText(stored.manualStation) || normalizeText(stored.detectedStation),
      hasManual: Boolean(normalizeText(stored.manualCompany) || normalizeText(stored.manualStation))
    };
  }

  async function renderStoredDetails(missingText = "Detecting…") {
    const stored = await chrome.storage.local.get(STORAGE_KEYS);
    const displayed = displayedDetails(stored);
    const state = displayed.hasManual
      ? "manual"
      : displayed.company && displayed.station
        ? "ready"
        : "waiting";

    renderDetails(displayed.company, displayed.station, state, missingText);
    return { stored, displayed };
  }

  async function saveDetectedDetails({ company, station }) {
    const updates = {};
    const normalizedCompany = normalizeText(company);
    const normalizedStation = normalizeText(station);

    if (isPlausibleValue(normalizedCompany)) {
      updates.detectedCompany = normalizedCompany;
    }

    if (isPlausibleValue(normalizedStation)) {
      updates.detectedStation = normalizedStation;
    }

    if (Object.keys(updates).length === 0) return;

    updates.detectedAt = Date.now();
    await chrome.storage.local.set(updates);
    await renderStoredDetails();
  }

  async function showOpenMenuMessageWhenEmpty() {
    const { displayed } = await renderStoredDetails("Open your user menu once");
    if (displayed.company || displayed.station) {
      renderDetails(
        displayed.company,
        displayed.station,
        displayed.hasManual ? "manual" : "waiting",
        "Open user menu once"
      );
    }
  }

  async function detectDetails({ mayOpenMenu = false } = {}) {
    if (detectionRunning || !document.body) return;
    detectionRunning = true;

    try {
      const direct = findSignedInDetailsInDom();
      if (direct.company || direct.station) {
        await saveDetectedDetails(direct);
      }

      if (direct.company && direct.station) return;
      if (!mayOpenMenu || !looksLikeStratusApplication()) return;

      const now = Date.now();
      if (now - lastMenuProbeAt < 30000) return;
      lastMenuProbeAt = now;

      const toggle = findLikelyAccountToggle();
      if (!toggle) {
        await showOpenMenuMessageWhenEmpty();
        return;
      }

      const wasExpanded = toggle.getAttribute("aria-expanded") === "true";
      if (!wasExpanded) toggle.click();

      await delay(450);

      const afterOpen = findSignedInDetailsInDom();
      if (afterOpen.company || afterOpen.station) {
        await saveDetectedDetails(afterOpen);
      }

      if (!wasExpanded) {
        await delay(80);
        toggle.click();
      }

      if (!afterOpen.company || !afterOpen.station) {
        await showOpenMenuMessageWhenEmpty();
      }
    } catch (error) {
      console.debug("STRATUS Company & Station Badge detection error:", error);
    } finally {
      detectionRunning = false;
    }
  }

  function startMutationObserver() {
    const observer = new MutationObserver(() => {
      window.clearTimeout(mutationTimer);
      mutationTimer = window.setTimeout(() => detectDetails({ mayOpenMenu: false }), 350);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;

    const relevantKeys = new Set(STORAGE_KEYS);
    if (!Object.keys(changes).some((key) => relevantKeys.has(key))) return;

    renderStoredDetails().then(({ displayed }) => {
      if (!displayed.company || !displayed.station) {
        detectDetails({ mayOpenMenu: true });
      }
    });
  });

  async function initialize() {
    ensureBadge();
    await renderStoredDetails();
    startMutationObserver();
    await detectDetails({ mayOpenMenu: true });

    window.setTimeout(() => detectDetails({ mayOpenMenu: true }), 1500);
    window.setTimeout(() => detectDetails({ mayOpenMenu: false }), 5000);
  }

  initialize();
})();
