(() => {
  "use strict";

  const HOST_ID = "svm-stratus-company-badge-host";
  const STORAGE_KEYS = ["manualCompany", "detectedCompany"];
  const LABEL_PATTERN = /^signed\s+into\s*:?\s*$/i;
  const INVALID_VALUE_PATTERN =
    /^(company|signed into|signed into station|account settings|refresh permissions|log out|logout)$/i;

  let shadowRoot = null;
  let valueElement = null;
  let mutationTimer = null;
  let lastMenuProbeAt = 0;
  let detectionRunning = false;

  function normalizeText(value) {
    return String(value ?? "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function isPlausibleCompany(value) {
    const text = normalizeText(value);
    return (
      text.length >= 2 &&
      text.length <= 120 &&
      !INVALID_VALUE_PATTERN.test(text) &&
      !/^signed\s+into\s+station\b/i.test(text)
    );
  }

  function ensureBadge() {
    let host = document.getElementById(HOST_ID);

    if (!host) {
      host = document.createElement("div");
      host.id = HOST_ID;
      host.setAttribute("aria-live", "polite");
      host.setAttribute("title", "Current STRATUS company");
      document.documentElement.appendChild(host);

      shadowRoot = host.attachShadow({ mode: "open" });

      const style = document.createElement("style");
      style.textContent = `
        :host {
          all: initial;
        }

        .badge {
          position: fixed;
          top: 5px;
          left: 50%;
          transform: translateX(-50%);
          z-index: 2147483647;
          display: inline-flex;
          align-items: center;
          gap: 8px;
          min-height: 26px;
          max-width: min(440px, 42vw);
          padding: 0 11px;
          box-sizing: border-box;
          border: 1px solid rgba(255, 255, 255, 0.22);
          border-radius: 5px;
          background: rgba(25, 25, 25, 0.96);
          box-shadow: 0 1px 4px rgba(0, 0, 0, 0.38);
          color: #ffffff;
          font-family: Arial, Helvetica, sans-serif;
          font-size: 12px;
          line-height: 1;
          pointer-events: none;
          user-select: none;
        }

        .label {
          color: #9db4c7;
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.08em;
        }

        .value {
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          font-weight: 600;
        }

        .badge[data-state="waiting"] .value {
          color: #d8d8d8;
          font-weight: 400;
        }

        @media (max-width: 900px) {
          .badge {
            left: auto;
            right: 185px;
            transform: none;
            max-width: 34vw;
          }
        }

        @media (max-width: 650px) {
          .badge {
            display: none;
          }
        }
      `;

      const badge = document.createElement("div");
      badge.className = "badge";
      badge.dataset.state = "waiting";

      const label = document.createElement("span");
      label.className = "label";
      label.textContent = "COMPANY";

      valueElement = document.createElement("span");
      valueElement.className = "value";
      valueElement.textContent = "Detecting…";

      badge.append(label, valueElement);
      shadowRoot.append(style, badge);
    } else if (!shadowRoot) {
      shadowRoot = host.shadowRoot;
      valueElement = shadowRoot?.querySelector(".value") ?? null;
    }

    return host;
  }

  function renderCompany(company, state = "ready") {
    ensureBadge();
    const badge = shadowRoot?.querySelector(".badge");
    if (!badge || !valueElement) return;

    badge.dataset.state = state;
    valueElement.textContent = normalizeText(company) || "Open your user menu once";
  }

  function linesFromElement(element) {
    return String(element?.innerText ?? "")
      .split(/\r?\n/)
      .map(normalizeText)
      .filter(Boolean);
  }

  function extractFromLabelElement(labelElement) {
    const directText = normalizeText(labelElement.textContent);
    const inlineMatch = directText.match(/^signed\s+into\s*:?\s+(.+)$/i);
    if (inlineMatch && isPlausibleCompany(inlineMatch[1])) {
      return normalizeText(inlineMatch[1]);
    }

    let current = labelElement;
    for (let level = 0; current && current !== document.body && level < 7; level += 1) {
      const lines = linesFromElement(current);
      const labelIndex = lines.findIndex((line) => LABEL_PATTERN.test(line));

      if (labelIndex >= 0) {
        for (let i = labelIndex + 1; i < Math.min(lines.length, labelIndex + 4); i += 1) {
          if (isPlausibleCompany(lines[i])) return lines[i];
        }
      }

      current = current.parentElement;
    }

    const siblingCandidates = [];
    let sibling = labelElement.nextElementSibling;
    for (let i = 0; sibling && i < 4; i += 1, sibling = sibling.nextElementSibling) {
      siblingCandidates.push(...linesFromElement(sibling));
    }

    return siblingCandidates.find(isPlausibleCompany) ?? null;
  }

  function findCompanyInDom() {
    if (!document.body) return null;

    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const text = normalizeText(node.nodeValue);
          if (LABEL_PATTERN.test(text) || /^signed\s+into\s*:?\s+\S+/i.test(text)) {
            return NodeFilter.FILTER_ACCEPT;
          }
          return NodeFilter.FILTER_REJECT;
        }
      }
    );

    let node;
    while ((node = walker.nextNode())) {
      const parent = node.parentElement;
      if (!parent) continue;

      const company = extractFromLabelElement(parent);
      if (company) return company;
    }

    return null;
  }

  function looksLikeStratusApplication() {
    const text = normalizeText(document.body?.innerText?.slice(0, 12000));
    return /assemblies/i.test(text) && /jobsites/i.test(text);
  }

  function candidateScore(element) {
    const rect = element.getBoundingClientRect();
    if (
      rect.width < 12 ||
      rect.height < 12 ||
      rect.bottom < 0 ||
      rect.top > 85 ||
      rect.right < window.innerWidth * 0.65
    ) {
      return -Infinity;
    }

    const descriptor = normalizeText(
      [
        element.getAttribute("aria-label"),
        element.getAttribute("title"),
        element.id,
        element.className,
        element.parentElement?.className
      ].join(" ")
    ).toLowerCase();

    let score = 0;
    if (/(account|profile|user|avatar|identity)/.test(descriptor)) score += 10;
    if (/(dropdown|menu|toggle)/.test(descriptor)) score += 4;
    if (element.matches('[aria-haspopup="menu"], [aria-haspopup="true"]')) score += 4;
    if (element.matches(".dropdown-toggle, [data-toggle='dropdown'], [data-bs-toggle='dropdown']")) score += 4;
    if (element.querySelector("img, svg")) score += 2;
    if (rect.right > window.innerWidth * 0.9) score += 3;
    score += rect.right / Math.max(window.innerWidth, 1);

    return score;
  }

  function findLikelyAccountToggle() {
    const selectors = [
      '[aria-label*="account" i]',
      '[aria-label*="profile" i]',
      '[aria-label*="user" i]',
      '[title*="account" i]',
      '[title*="profile" i]',
      '[title*="user" i]',
      ".dropdown-toggle",
      "[data-toggle='dropdown']",
      "[data-bs-toggle='dropdown']",
      '[aria-haspopup="menu"]',
      '[aria-haspopup="true"]'
    ];

    const candidates = [...new Set(document.querySelectorAll(selectors.join(",")))]
      .map((element) => ({ element, score: candidateScore(element) }))
      .filter((item) => Number.isFinite(item.score))
      .sort((a, b) => b.score - a.score);

    return candidates[0]?.score >= 5 ? candidates[0].element : null;
  }

  function delay(milliseconds) {
    return new Promise((resolve) => window.setTimeout(resolve, milliseconds));
  }

  async function loadStoredCompany() {
    const stored = await chrome.storage.local.get(STORAGE_KEYS);
    const manual = normalizeText(stored.manualCompany);
    const detected = normalizeText(stored.detectedCompany);

    if (manual) {
      renderCompany(manual, "manual");
      return { manual, detected };
    }

    if (detected) {
      renderCompany(detected, "ready");
    } else {
      renderCompany("Detecting…", "waiting");
    }

    return { manual, detected };
  }

  async function saveDetectedCompany(company) {
    const normalized = normalizeText(company);
    if (!isPlausibleCompany(normalized)) return;

    await chrome.storage.local.set({
      detectedCompany: normalized,
      detectedAt: Date.now()
    });

    const stored = await chrome.storage.local.get(["manualCompany"]);
    if (!normalizeText(stored.manualCompany)) {
      renderCompany(normalized, "ready");
    }
  }

  async function detectCompany({ mayOpenMenu = false } = {}) {
    if (detectionRunning || !document.body) return;
    detectionRunning = true;

    try {
      const direct = findCompanyInDom();
      if (direct) {
        await saveDetectedCompany(direct);
        return;
      }

      if (!mayOpenMenu || !looksLikeStratusApplication()) return;

      const now = Date.now();
      if (now - lastMenuProbeAt < 30000) return;
      lastMenuProbeAt = now;

      const toggle = findLikelyAccountToggle();
      if (!toggle) {
        const stored = await chrome.storage.local.get(STORAGE_KEYS);
        if (!normalizeText(stored.manualCompany) && !normalizeText(stored.detectedCompany)) {
          renderCompany("Open your user menu once", "waiting");
        }
        return;
      }

      const wasExpanded = toggle.getAttribute("aria-expanded") === "true";
      if (!wasExpanded) toggle.click();

      await delay(450);

      const afterOpen = findCompanyInDom();
      if (afterOpen) await saveDetectedCompany(afterOpen);

      if (!wasExpanded) {
        await delay(80);
        toggle.click();
      }

      if (!afterOpen) {
        const stored = await chrome.storage.local.get(STORAGE_KEYS);
        if (!normalizeText(stored.manualCompany) && !normalizeText(stored.detectedCompany)) {
          renderCompany("Open your user menu once", "waiting");
        }
      }
    } catch (error) {
      console.debug("STRATUS Company Badge detection error:", error);
    } finally {
      detectionRunning = false;
    }
  }

  function startMutationObserver() {
    const observer = new MutationObserver(() => {
      window.clearTimeout(mutationTimer);
      mutationTimer = window.setTimeout(() => detectCompany({ mayOpenMenu: false }), 350);
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;

    if (changes.manualCompany) {
      const manual = normalizeText(changes.manualCompany.newValue);
      if (manual) {
        renderCompany(manual, "manual");
        return;
      }

      chrome.storage.local.get(["detectedCompany"]).then(({ detectedCompany }) => {
        const detected = normalizeText(detectedCompany);
        renderCompany(detected || "Detecting…", detected ? "ready" : "waiting");
        if (!detected) detectCompany({ mayOpenMenu: true });
      });
    }

    if (changes.detectedCompany && !changes.manualCompany) {
      chrome.storage.local.get(["manualCompany"]).then(({ manualCompany }) => {
        if (!normalizeText(manualCompany)) {
          const detected = normalizeText(changes.detectedCompany.newValue);
          renderCompany(detected || "Detecting…", detected ? "ready" : "waiting");
        }
      });
    }
  });

  async function initialize() {
    ensureBadge();
    await loadStoredCompany();
    startMutationObserver();
    await detectCompany({ mayOpenMenu: true });

    window.setTimeout(() => detectCompany({ mayOpenMenu: true }), 1500);
    window.setTimeout(() => detectCompany({ mayOpenMenu: false }), 5000);
  }

  initialize();
})();
