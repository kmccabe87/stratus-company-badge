"use strict";

const currentCompany = document.getElementById("currentCompany");
const manualCompany = document.getElementById("manualCompany");
const saveButton = document.getElementById("saveButton");
const clearButton = document.getElementById("clearButton");
const message = document.getElementById("message");

function normalize(value) {
  return String(value ?? "").replace(/\s+/g, " ").trim();
}

async function refresh() {
  const stored = await chrome.storage.local.get(["manualCompany", "detectedCompany"]);
  const manual = normalize(stored.manualCompany);
  const detected = normalize(stored.detectedCompany);

  currentCompany.textContent = manual || detected || "Not detected yet";
  manualCompany.value = manual;
}

saveButton.addEventListener("click", async () => {
  const value = normalize(manualCompany.value);

  if (!value) {
    message.textContent = "Enter a company name first.";
    return;
  }

  await chrome.storage.local.set({ manualCompany: value });
  message.textContent = "Manual override saved.";
  await refresh();
});

clearButton.addEventListener("click", async () => {
  await chrome.storage.local.remove("manualCompany");
  message.textContent = "Auto-detect restored.";
  await refresh();
});

refresh();
